"use strict"
let personName = prompt('Whats your name?', '');
let personSureName = prompt('Whats your surename?', '');

console.log('Your name is ' + personName + ' ' + personSureName);

let num1 = prompt('First number','');
let num2 = prompt('Second number','');

console.log(+num1 + +num2);

let num3 = prompt('Enter number 1');
let num4 = prompt('Enter number 2');

console.log(+num3 * +num4);